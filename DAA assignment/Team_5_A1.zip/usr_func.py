
import random    # taking random numbers by importing function random


#candles=list()

def birthdaycakecandles(age):    # defining birthdaycakecandles as an function       
    candles=[random.randint(0,age) for i in range(0,age)]    # creating random numbers for the given age no of candles 
    
    #ANOTHER METHOD TO ACCOMPLISH THE TASK
    #for i in range(0,age):
        #candles.append(random.randint(0,age))
        #candles.append(random.randrange(0,age+1))
        
    return candles,max(candles),candles.count(max(candles))    # returning  candles, tallest candle, count of tallest candles
    
