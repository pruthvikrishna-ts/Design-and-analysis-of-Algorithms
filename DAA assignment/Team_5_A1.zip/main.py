
from usr_func import  birthdaycakecandles
    

while True:
	try:

		age=int(input("Enter the Age:"))    # prompt ur age
		candles,tallest_candle,count_tallest_candle=birthdaycakecandles(age)    # storing returned values from birthdaycakecandles

		print("Candles:",candles)    # printing all the candles
		print("Tallest candle:",tallest_candle)    # printing the tallest candle
		print("You have to blow:",count_tallest_candle,"candles")    # printing the count of the tallest candles 
		exit()
	except ValueError:
		print("Please enter the positive integer only!!")










